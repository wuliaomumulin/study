<?php
use App\Rpc\CalculatorServiceInterface;

return [
	'consumers' => [
		[
			'name' => 'CalculatorService',
			'service' => CalculatorServiceInterface::class,
			//注册中心
			'registry' => [
				'protocol' => 'consul',
				'address' => 'http://127.0.0.1:8500'
			],
			/*'nodes' => [
				['host' => '127.0.0.1','port' => 9502]
			],*/
		],
		
	]
];
?>