<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://doc.hyperf.io
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf-cloud/hyperf/blob/master/LICENSE
 */

use Hyperf\HttpServer\Router\Router;

Router::addRoute(['PATCH','DELETE','PUT','GET', 'POST', 'HEAD'], '/', 'App\Controller\IndexController@index');
//Router::addRoute(['PATCH','DELETE','PUT','GET', 'POST', 'HEAD'], '/index/store', 'App\Controller\IndexController@store');

// 创建对应的路由方法
Router::addServer('ws',function(){
	//第一种类型
/*  Router::addGroup('/user/',function(){
  	Router::get('index','App\Controller\WebSocketController');
  	Router::get('index1','App\Controller\WebSocketController');
  	Router::get('index2','App\Controller\WebSocketController');
  	Router::get('index3','App\Controller\WebSocketController');
  });*/
  	//第二种类型，screen屏幕,必选参数type类型
  	Router::get('/screen/{type}','App\Controller\WebSocketController');

});
