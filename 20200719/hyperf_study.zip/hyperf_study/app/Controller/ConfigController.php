<?php

declare(strict_types=1);

namespace App\Controller;

//注解
use Hyperf\Di\Annotation\Inject;
use Hyperf\Config\Annotation\Value;

use Hyperf\HttpServer\Annotation\AutoController;

//注解中间件
use Hyperf\HttpServer\Annotation\Middleware;
use Hyperf\HttpServer\Annotation\Middlewares;
use App\Middleware\FooMiddleware;
use App\Middleware\BarMiddleware;
use App\Middleware\BazMiddleware;


use Hyperf\HttpServer\Contract\RequestInterface;
/**
 * @AutoController()
 * @Middlewares(
 *      @Middleware(BarMiddleware::class),
 *      @Middleware(BazMiddleware::class)
 * )
 * 配置的获取
 */
class ConfigController
{

    /**
    * @Inject()
    * @var \Hyperf\Contract\ConfigInterface
    */
    private $config;
    /**
    * @Value("foo.bar")
    */
    private $bar;

    /**
    需要加一个乘号@Middleware(FooMiddleware::class)
    *
    * 方法中间件
    */
    public function index()
    {

      return $this->config->get('foo.bar',123);

    }
    public function value(){
      return $this->bar;  
    }
    //通过全局函数
    public function config(){
      //return config('foo.bar',1234);
      return config('server.servers',1234);
    }
    //环境变量
    //php bin/hyperf.php gen:middleware BazMiddleware

    /*中间件的执行顺序
       全局中间件 > 类中间件 > 方法中间件
       
       全局中间件可以做校验,token

    */
    public function index1(RequestInterface $request){
        $fooValue = $request->getAttribute('foo');
        return $fooValue;
    }

}
