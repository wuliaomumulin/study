<?php
declare(strict_types=1);

namespace App\Controller;

use Hyperf\Contract\OnCloseInterface;
use Hyperf\Contract\OnMessageInterface;
use Hyperf\Contract\OnOpenInterface;
use Swoole\Http\Request;
use Swoole\Server;
use Swoole\Websocket\Frame;
use Swoole\WebSocket\Server as WebSocketServer;

class WebSocketController implements OnMessageInterface, OnOpenInterface, OnCloseInterface
{
    //protected $server = NULL;
    //protected $request = NULL;


    public function onMessage(WebSocketServer $server, Frame $frame): void
    {
        $server->push($frame->fd, 'Recv: ' . $frame->data);
    }

    public function onClose(Server $server, int $fd, int $reactorId): void
    {
        var_dump('closed');
    }

    public function onOpen(WebSocketServer $server, Request $request): void
    {

        //利用请求头去分发请求
        $cur =  substr($request->server['path_info'],8);
        //定义一个可访问方法的数组
        $routes = array(
            'aaa',
            'bbb',
            'ccc',
            'ddd',
            'eee',
            );
        if(in_array($cur,$routes)){
            $this->server = $server;
            $this->request = $request;
            $this->$cur();
            //不会断掉下面的代码
        }else{
            $server->push($request->fd, '非法路由');
        }
        
    }

    //业务代码，可以操作数据库，也可以操作linux
    public function aaa(): void
    {
        $this->server->push($this->request->fd, __FUNCTION__);
    }
    public function bbb(): void
    {
        $this->server->push($this->request->fd, __FUNCTION__);
    }
    public function ccc(): void
    {
        $this->server->push($this->request->fd, __FUNCTION__);
    }
    public function ddd(): void
    {
        $this->server->push($this->request->fd, __FUNCTION__);
    }
    public function eee(): void
    {
        $this->server->push($this->request->fd, __FUNCTION__);
    }
    //调用的方法不存在
    public function __call($callback,$arguments){
        print("不存在的方法,{$callback}");
    }    
}
