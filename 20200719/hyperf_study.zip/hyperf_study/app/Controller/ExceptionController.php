<?php

declare(strict_types=1);

namespace App\Controller;

//注解
use Hyperf\Di\Annotation\Inject;
use Hyperf\Config\Annotation\Value;

use Hyperf\HttpServer\Annotation\AutoController;
use App\Exception\Handler\FooExceptionHandler;
use App\Exception\FooException;

use Hyperf\HttpServer\Contract\RequestInterface;
/**
 * @AutoController()
 * 异常处理
 */
class ExceptionController
{

    public function index()
    {
        return __METHOD__;
    }

    public function co(){

        co(function(){
            while(true){
                echo date('Y-m-d H:i:s');
                sleep(1);
            }
        });
        return __METHOD__;
    }

    public function exception(){
        throw new FooException('测试抛出异常');
    }

}
