<?php

declare(strict_types=1);

namespace App\Controller;

//注解
use Hyperf\Di\Annotation\Inject;
//注解类
use App\Annotation\Foo;
use Hyperf\Di\Annotation\AnnotationCollector;
use Hyperf\HttpServer\Annotation\AutoController;

use Hyperf\HttpServer\Contract\RequestInterface;

//协程创建
use Swoole\Coroutine\Channel;
use Hyperf\Utils\WaitGroup;
use Hyperf\Utils\Parallel;
//use Hyperf\Utils\Coroutine;
/**
 * @AutoController()
 * 
 * 协程使用
 */
class CoController
{
    private $userService;

    /**
     * @Inject()
     * @var \Hyperf\Guzzle\ClientFactory
     * 主要是创建一个协程HTTP客户端
     */
    private $clientFactory;

    //模拟IO操作
    public function index()
    {
        //串行花费4118ms
        // $client = $this->clientFactory->create();
        // $client->get('127.0.0.1:9501/co/sleep?seconds=2');
        // $client = $this->clientFactory->create();
        // $client->get('127.0.0.1:9501/co/sleep?seconds=2');

        //并行花费2068ms
        /*$channel = new Channel();
        co(function() use ($channel){
        $client = $this->clientFactory->create();
        $client->get('127.0.0.1:9501/co/sleep?seconds=2');
        $channel->push(\Hyperf\Utils\Coroutine::id());//获取协程id
       });
       co(function() use ($channel){
        $client = $this->clientFactory->create();
        $client->get('127.0.0.1:9501/co/sleep?seconds=2');
        $channel->push(\Hyperf\Utils\Coroutine::id());
       });
       $ret[] = $channel->pop();//调度和通知
       $ret[] = $channel->pop();
       return $ret;*/

       //WaitGroup
       /*$wg = new WaitGroup();
       //由于是两个协程，所以需要明确协程数量
       $wg->add(2);

       $ret = [];
       co(function() use($wg,&$ret){
            $client = $this->clientFactory->create();
            $client->get('127.0.0.1:9501/co/sleep?seconds=2');
            $ret[] = \Hyperf\Utils\Coroutine::id();
            $wg->done();//子协程计数器-1
       });
       co(function() use($wg,&$ret){
            $client = $this->clientFactory->create();
            $client->get('127.0.0.1:9501/co/sleep?seconds=2');
            $ret[] = \Hyperf\Utils\Coroutine::id();
            $wg->done();
       });
       //等待协程全部运行完成，执行之后的内容
       $wg->wait();

       return $ret;*/

       //Parallel平行,他是对WaitGroup的一个简单封装
       /*$parallel = new Parallel();
       $parallel->add(function(){
            $client = $this->clientFactory->create();
            $client->get('127.0.0.1:9501/co/sleep?seconds=2');
            return \Hyperf\Utils\Coroutine::id();
       });
       $parallel->add(function(){
            $client = $this->clientFactory->create();
            $client->get('127.0.0.1:9501/co/sleep?seconds=2');
            return \Hyperf\Utils\Coroutine::id();
       });
       $ret = $parallel->wait();
       return $ret;*/

        $ret = parallel([
        function(){
            $client = $this->clientFactory->create();
            $client->get('127.0.0.1:9501/co/sleep?seconds=2');
            return \Hyperf\Utils\Coroutine::id();
       },
       function(){
            $client = $this->clientFactory->create();
            $client->get('127.0.0.1:9501/co/sleep?seconds=2');
            return \Hyperf\Utils\Coroutine::id();
       }
       ]);
       return $ret;


    }

    public function sleep(RequestInterface $request1){


        $seconds = (int)$request1->input('seconds',1);
        sleep($seconds);
        return $seconds;
    }

    //demo
    public function test(){
        /*1、
        Coroutine::create(function(){
            sleep(1);
            echo __LINE__;
        });*/
        /* 2、
        go(function(){
            sleep(1);
            echo __LINE__;
        });*/
        co(function(){
            sleep(1);
            echo __LINE__;
        });

    }
}
