<?php

declare(strict_types=1);

namespace App\Controller;

//注解
use Hyperf\Di\Annotation\Inject;

use Hyperf\HttpServer\Annotation\AutoController;




use Hyperf\HttpServer\Contract\RequestInterface;
/**
 * @AutoController()
 */
class EventController
{

    /**
    * @Inject()
    * @var \App\Service\UserService
    */
    private $UserService;

    public function register()
    {

      return $this->UserService->register();

    }
}