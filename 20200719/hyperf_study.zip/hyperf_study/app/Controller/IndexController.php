<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://doc.hyperf.io
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf-cloud/hyperf/blob/master/LICENSE
 */
namespace App\Controller;

use Hyperf\DbConnection\Db;

//注解
use Hyperf\Di\Annotation\Inject;
//注解类
use App\Annotation\Foo;
use Hyperf\Di\Annotation\AnnotationCollector;
use Hyperf\HttpServer\Annotation\AutoController;
//协程上下文的切换
use Hyperf\HttpServer\Contract\RequestInterface;
use Hyperf\Utils\Context;

/**
 * @AutoController()
 * @foo(bar="123",baz="321")
 * 注解类赋值
 */
class IndexController extends AbstractController
{
    private $userService;

    private $foo1;

    public function index()
    {
        $user = $this->request->input('user', 'Hyperf');
        $method = $this->request->getMethod();

        return [
            'method' => $method,
            'message' => "Hello {$user}.",
        ];
    }

    public function store(){
        var_dump(AnnotationCollector::getClassByAnnotation(Foo::class));
    	return __METHOD__;
    }


    //测试数据的混淆
    public function index1(RequestInterface $request1){
        $this->foo1 = $request1->input('foo1');
        return $this->foo1;
    }

    public function index11(){
        return $this->foo1;
    }
    //测试数据不混淆
    public function index12(RequestInterface $request1){
        Context::set('foo2',$request1->input('foo2'));
        return Context::get('foo2');
    }
    //上下文
    public function index13(){
        return Context::get('foo2');
    }
}
