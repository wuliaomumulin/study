<?php
/***
* class Timer
*/
class Timer extends SplMinHeap{
	/***
	* 比较根节点和新插入节点的大小
	* @param mixed $value1
	* @param mixed $value2
	*/
	public function compare($value1,$value2){
		return $value2['timeout'] <=> $value1['timeout'];
	}
	/**
	 * 插入节点
	 * @param mixed $value
	 */
	public function insert($value){
		$value['timeout'] = time() + $value['expire'];
		parent::insert($value);
	}
	/**
	 * 监听
	 * @param bool $debug
	 */
	public function monitor($debug = false){
    	// 判断是否为空堆
		while(!$this->isEmpty()){
			$this->exec($debug);
			usleep(1000);
		}
	}
	/**
	 * 执行
	 * @param bool $debug
	 */
	public function exec($debug){
		$hit = 0;
		$tl = microtime(true);
		//判断是否为空堆
		while(!$this->isEmpty()){
			//返回堆的顶部节点
			$node = $this->top();
			if($node['timeout'] <= time()){
				//出堆或入堆
				$node['repeat'] ? $this->insert($this->extract()) : $this->extract();
				$hit = 1;
				//开启子进程
				if(pcntl_fork() == 0){
					empty($node['action']) ? '' : call_user_func($node['action']);
					exit(0);
				}
				//安装一个信号器，忽略子进程，子进程退出由系统回收
				pcntl_signal(SIGCLD,SIG_IGN);

			}else{
				break;
			}
		}
		$t2 = microtime(true);
		echo ($debug && $hit) ? '时间堆 - 调整耗时:'.round($t2-$t1,3)."秒\r\n" : '';
	}
}


//测试
class Test{
	public static function consumer(){
		echo '3秒 - 重复 - consumer'.PHP_EOL;
	}
}

$timer = new Timer();

//注册-3s-重复触发
$timer->insert(
	array(
		'expire'=>3,
		'repeat'=>true,
		'action'=>function(){
			echo '3秒 - 重复 - hello,world'.PHP_EOL;
		}
		)
	);
//注册-3s-重复触发
$timer->insert(
	array(
		'expire'=>3,
		'repeat'=>true,
		'action'=>function(){
			echo '3秒 - 重复 - gogogo'.PHP_EOL;
		}
		)
	);
//注册-6s-触发一次
$timer->insert(
	array(
		'expire'=>6,
		'repeat'=>false,
		'action'=>function(){
			echo '6秒 - 一次 - lin'.PHP_EOL;
		}
		)
	);
//注册-3s-重复触发
$timer->insert(
	array(
		'expire'=>3,
		'repeat'=>true,
		'action'=>function(){
			Test::consumer();
			}
		)
	);
//监听
$timer->monitor(false);
?>