<?php
namespace App\Rpc;
/**
 * 
 */
class CalculatorService
{
	
	public function add(int $a,int $b): int
	{
		return $a + $b;
	}
	public function minus(int $a,int $b): int
	{
		return $a - $b;
	}

}


	
?>