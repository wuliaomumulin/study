<?php
namespace App\Event;

class BeforeUserRegister{
	/**
	* @var bool
	*/
	public $shouldRegister = true;


}

?>