<?php
namespace App\Event;

class UserRegistered{
	public $uid;

	public function __construct(int $uid){
		$this->uid = $uid;
	}
}

?>