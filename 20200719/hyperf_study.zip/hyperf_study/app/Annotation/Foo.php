<?php
namespace App\Annotation;


use Hyperf\Di\Annotation\AbstractAnnotation;
/**
 * @Annotation
 * @Target({"CLASS","METHOD"})
 */
class Foo extends AbstractAnnotation{

	/**
	 * @var string
	 * 注解类属性
	 */
	public $bar;
	 /**
	 * @var string
	 */
	public $baz;

	public function __construct($value = null){
		var_dump($value);
		parent::__construct($value);
	}
}
?>