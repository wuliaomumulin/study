<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://doc.hyperf.io
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */

namespace App\Exception\Handler;

use Hyperf\Contract\StdoutLoggerInterface;
use Hyperf\ExceptionHandler\ExceptionHandler;
use Hyperf\HttpMessage\Stream\SwooleStream;
use Psr\Http\Message\ResponseInterface;
use Throwable;

use App\Exception\FooException;

class FooExceptionHandler extends ExceptionHandler
{

    public function handle(Throwable $throwable, ResponseInterface $response)
    {
        echo __METHOD__.PHP_EOL;
        //阻止错误向上冒泡
        $this->stopPropagation();
        return $response->withHeader("Server", "znlh")->withStatus(500)->withBody(new SwooleStream('这是一个Foo对象'.__METHOD__));
    }

    public function isValid(Throwable $throwable): bool
    {
        return $throwable instanceof FooException;
    }
}
