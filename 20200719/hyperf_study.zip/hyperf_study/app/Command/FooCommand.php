<?php

declare(strict_types=1);

namespace App\Command;

use Hyperf\Command\Command as HyperfCommand;
use Hyperf\Command\Annotation\Command;
use Psr\Container\ContainerInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;

/**
 * @Command
 */ 
class FooCommand extends HyperfCommand
{
    /**
     * @var ContainerInterface
     */
    protected $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;

        parent::__construct('demo:command');
    }

    public function configure()
    {
        parent::configure();
        $this->setDescription('Hyperf Demo Command');
        $this->addOption('option1','o1',InputOption::VALUE_OPTIONAL,'描述1','默认值1');
        $this->addOption('option2','o2',InputOption::VALUE_IS_ARRAY |  InputOption::VALUE_OPTIONAL,'描述2',['默认值2']);
        $this->addArgument('name',InputArgument::OPTIONAL,'名字','liyb1');
        $this->addArgument('sex',InputArgument::OPTIONAL,'性别','先生');
    }

    public function handle()
    {
        $option1 = $this->input->getOption('option1');
        $option2 = implode(',',$this->input->getOption('option2'));
        $name = $this->input->getArgument('name');
        $sex = $this->input->getArgument('sex');
        $this->line(sprintf('Hello %s %s!,描述1为%s,描述2为%s',$name,$sex,$option1,$option2), 'info');
        $this->output->writeln('***********<error>下面为交互模式输出项目</error>*****************');
        $this->output->writeln('名称为'.$this->output->ask('姓名?','liyb'));
        $this->output->writeln('启用通讯录为'.(int)$this->output->confirm('不开启通讯录?',false));
        $this->output->writeln('安装服务为'.$this->output->choice('选择一个服务?',['apache2','nginx','npm','php','jdk']));
        $this->output->progressStart(100);
        for($i=0;$i<10;$i++){
            $this->output->progressAdvance(10);
            sleep(1);
        }
        $this->output->progressFinish();
        $this->output->writeln('测试完成');

    }

    /**
     *
     *
php bin/start.php gen:command FooCommand
## 输入项目
php bin/hyperf.php demo:command
php bin/hyperf.php demo:command liyb
php bin/hyperf.php demo:command --option1 个人信息1
php bin/hyperf.php demo:command --option1=个人信息1
php bin/hyperf.php demo:command --option1 "个人 信息1"
php bin/hyperf.php demo:command --option1 "个人 信息1" --option2 个人信息2 --option2 个人信息2.1

## 输出项目
     * 
     */
}
