<?php

declare(strict_types=1);

namespace App\Listener;

use Hyperf\Event\Annotation\Listener;
use Psr\Container\ContainerInterface;
use Hyperf\Event\Contract\ListenerInterface;
use App\Event\UserRegistered;
use App\Event\BeforeUserRegister;
/**
 * @Listener(priority=8)
 */
class LogEventListener implements ListenerInterface
{
    /**
     * @var ContainerInterface
     */
    private $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function listen(): array
    {
        return [
            BeforeUserRegister::class,
            UserRegistered::class,
        ];
    }

    public function process(object $event)
    {
        if($event instanceof BeforeUserRegister){
            echo get_class($event).$event->shouldRegister.PHP_EOL;
        }elseif($event instanceof UserRegistered){
            echo get_class($event).$event->uid.PHP_EOL;
        }
    }
}
