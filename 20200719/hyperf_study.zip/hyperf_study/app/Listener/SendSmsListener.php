<?php

declare(strict_types=1);

namespace App\Listener;

use Hyperf\Event\Annotation\Listener;
use Psr\Container\ContainerInterface;
use Hyperf\Event\Contract\ListenerInterface;
use App\Event\UserRegistered;

/**
 * @Listener(priority=10)
 */
class SendSmsListener implements ListenerInterface
{
    /**
     * @var ContainerInterface
     */
    private $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function listen(): array
    {
        return [
            UserRegistered::class,
        ];
    }
    /**
    * @param UserRegistered $event
    */
    public function process(object $event)
    {
        echo __METHOD__.':发送短信给'.$event->uid.PHP_EOL;//异常捕获

    }
}
