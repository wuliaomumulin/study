<?php
namespace App\Service;

use App\Event\UserRegistered;
use App\Event\BeforeUserRegister;
use Hyperf\Di\Annotation\Inject;
/**
事件解耦
事件Event Listener EventDispatcher
*/
class UserService
{
	/**
	* @Inject()
	* @var \Psr\EventDispatcher\EventDispatcherInterface
	*/
	private $EventDispatcher;

	//注册的用户id
	public function register(){
		//注册之前
		$beforeUserRegister = new BeforeUserRegister();
		$this->EventDispatcher->dispatch($beforeUserRegister);


		if($beforeUserRegister->shouldRegister){
			//注册成功
			$uid = rand(10,9999);
		}else{
			//不注册
			return '不允许注册';
		}
		

		//注册成功之后
		if($uid){
			$this->EventDispatcher->dispatch(new UserRegistered($uid));

			//$this->sendSms();
			//$this->sendEmail();
			//同步用户信息到其他系统
			//将用户注册成功的信息搜集到用户行为分析系统
			//...
			//可以通过事件模式去解耦业务数据
		}

		return $uid;
	}

/*	public function sendSms(){
		echo __METHOD__.PHP_EOL;//异常捕获
	}

	public function sendEmail(){
		echo __METHOD__.PHP_EOL;//异常捕获
	}*/
}
	
?>