<?php
namespace App\Aspect;

use App\Controller\IndexController;
use Hyperf\Di\Annotation\Aspect;
use Hyperf\Di\Aop\AbstractAspect;
use Hyperf\Di\Aop\ProceedingJoinPoint;

/**
 * @Aspect
 */
class IndexAspect extends AbstractAspect
{

	public $classes = [
		IndexController::class.'::'.'store',
	];

	public function process(ProceedingJoinPoint $ProceedingJoinPoint){
		echo __METHOD__;

		$ret = $ProceedingJoinPoint->process();
		return 'before'.$ret.'after';
	}
}

?>