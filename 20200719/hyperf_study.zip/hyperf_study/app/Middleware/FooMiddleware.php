<?php

declare(strict_types=1);

namespace App\Middleware;

use Psr\Container\ContainerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;

use Hyperf\HttpMessage\Stream\SwooleStream;
use Hyperf\Utils\Context;

class FooMiddleware implements MiddlewareInterface
{
    /**
     * @var ContainerInterface
     */
    protected $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        echo __METHOD__.PHP_EOL;

        //携带属性
        //1、
        // $request = Context::override(ServerRequestInterface::class,function() use($request){
        //     return $request->withAttribute('foo',123);
        // });
        //2、
        $request = $request->withAttribute('foo',123);        

        $response = $handler->handle($request);
        echo __METHOD__.PHP_EOL;

        $body = $response->getBody()->getContents();
        return $response->withBody(new SwooleStream($body.__LINE__));
    }
}