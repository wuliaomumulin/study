annotation注解
aspect切入
aop切面



1、协程间的数据混淆
> 通过代理类的方法去解决，在php中代理类可以是一个interface,如果requestInterface绑定的实际是一个代理类，代理的所有方法都是从Context里面取出对应的对象进行操作。
协程上下文的切换 ConText:set|get
co
2、config

3、middleware
洋葱圈模型
php bin/hyperf.php gen:middleware BazMiddleware



4、consul
apt-get install consul
consul agent -dev -bind 19.19.19.11 -client 0.0.0.0 -ui

5、rpc-server和rpc-client,server发布到consul暂未实现，需要consul依赖包;
发布对应的consul配置文件
php bin/hyperf.php vendor:publish hyperf/consul

6、异常处理
继承自\RuntimeException
7、事件机制
事件解耦
 事件Event Listener EventDispatcher
# 创建一个监听器
php bin/hyperf.php gen:listener SendSmsListener

监听器的优先级可以通过在监听类的priority决定
**
 * @Listener(priority=9)
 *

8、命令行
